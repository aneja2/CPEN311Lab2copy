# Contributions
List of contributions made by members of the team.

It is highly recommended that you each work individually on this specific task. However, only one solution needs to be pushed to GitHub.

## Contributions made by ABC DEF
- contribution 1
- contribution 2

## Contributions made by TUV XYZ
- contribution 1
- contribution 2

